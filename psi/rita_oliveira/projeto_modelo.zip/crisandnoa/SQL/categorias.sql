INSERT INTO categorias (nome, descricao, slug) VALUES
('Roupinhas', 'Camisolas, pijamas e casacos para gatos', 'roupinhas'),
('Acessórios', 'Coleiras, laços, chapéus e lenços para gatos', 'acessorios'),
('Brinquedos', 'Peluches, ratinhos e bolas para diversão dos gatos', 'brinquedos'),
('Camas & Mantas', 'Camas, mantas e confortos para os gatos', 'camas-mantas'),
('Outros', 'Tigelas, mochilas transportadoras e outros acessórios', 'outros');
