INSERT INTO tamanhos (nome) VALUES
('XS'),
('S'),
('M'),
('L');