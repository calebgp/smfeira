INSERT INTO produtos (nome, descricao, preco, categoria_id, imagem, slug) VALUES
('Camisola Rosa', 'Camisola fofinha rosa para gatos', 19.90, 1, 'camisola_rosa.jpg', 'camisola-rosa'),
('Camisola Verde Riscas', 'Camisola verde com riscas para gatos', 21.50, 1, 'camisola_verde_riscas.jpg', 'camisola-verde-riscas'),
('Casaco com Carapuço Azul', 'Casaco com capuz azul confortável', 29.90, 1, 'casaco_carapuco_azul.jpg', 'casaco-carapuco-azul'),
('Sweater Carapuço Vermelha/Azul', 'Sweater com capuz em vermelho e azul', 24.90, 1, 'sweater_carapuco_vermelha_azul.jpg', 'sweater-carapuco-vermelha-azul'),
('Sweater Cobertor Azul', 'Sweater tipo cobertor azul', 26.50, 1, 'sweater_cobertor_azul.jpg', 'sweater-cobertor-azul'),
('Sweater Verde com Orelhas', 'Sweater verde com orelhinhas', 27.90, 1, 'sweater_verde_orelhas_azul.jpg', 'sweater-verde-orelhas-azul'),
('Top Colorido Riscas', 'Top colorido com riscas', 18.90, 1, 'top_colorido_riscas.jpg', 'top-colorido-riscas'),
('Vestido com Folhos Rosa', 'Vestido com folhos rosa', 32.90, 1, 'vestido_folhos_rosa.jpg', 'vestido-folhos-rosa'),
('Vestido Veludo Verde', 'Vestido em veludo verde', 34.90, 1, 'vestido_veludo_verde.jpg', 'vestido-veludo-verde'),
('Top Rosa Corações', 'Top rosa com corações', 19.90, 1, 'top_rosa_coracoes.jpg', 'top-rosa-coracoes');
