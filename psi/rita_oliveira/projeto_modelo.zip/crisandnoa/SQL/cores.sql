INSERT INTO cores (nome, codigo_hex) VALUES
('Preto', '#000000'),
('Branco', '#FFFFFF'),
('Cinza', '#808080'),
('Bege', '#F5F5DC'),
('Rosa', '#FFC0CB'),
('Azul', '#0000FF'),
('Vermelho', '#FF0000'),
('Verde', '#008000'),
('Amarelo', '#FFFF00');